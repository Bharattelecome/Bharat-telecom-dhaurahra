# Bharat Telecom Dhaurahara — online starter

Responsive starter for inventory, customer records, sales, basic finance plans, installment payments, dashboard totals and admin/staff accounts. Uses Express + SQLite and server-side sessions.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Set environment variables before first run:
   - `ADMIN_PASSWORD` — required, at least 12 characters, choose a unique strong password.
   - `SESSION_SECRET` — required in production, long random secret.
   - `NODE_ENV=production` in production.
   - `ADMIN_USERNAME` optional (defaults to `admin`).
4. Run `npm start` and open `http://localhost:3000`.

The first run creates the admin account only if no users exist. Never use a sample/default password. Set secrets using your hosting provider's secret/environment-variable settings; do not commit them to source control.

## Deployment requirements
Deploy to a Node.js host with persistent disk/storage for `bharat-telecom.sqlite` and `sessions.sqlite`; configure HTTPS, environment secrets, restricted admin access, automated encrypted backups and tested restores. A host with ephemeral filesystem will lose the database unless a persistent volume is configured. Do not expose the app publicly before reviewing access controls, rate limiting, backup, privacy and applicable Indian data-protection requirements. SQLite is a starter; for a larger multi-user shop system, use managed PostgreSQL and managed session storage.

## Current starter scope and limitations
- Product add/list, unique optional IMEI, stock decrement on sale, customer add/list, sale history, simple-interest finance plan, payment ledger, admin-created users, admin/staff role checks.
- Product deletion is admin-only and blocked when foreign-key history exists.
- Finance calculation is illustrative simple interest, not a lender quote. It does not create legal finance agreements or automate reminders.
- No PDF invoice export, GST invoice workflow, refunds/returns, audit-log UI, OTP, password reset, rate limiting, CSRF token flow, or external payment gateway yet. Add and test these before production use.
- Customer information and IMEI are sensitive. Enter only authorized records and keep backups secure.
